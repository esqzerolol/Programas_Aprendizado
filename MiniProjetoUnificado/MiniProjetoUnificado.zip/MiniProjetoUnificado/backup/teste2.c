#include <stdio.h>

int main (){
    double a = 1;
    double b = 2.1;
    double c = 3.12;
    double d = 4.123;
    double e = 5.1234;
    double f = 6.123456789101112131415;

    printf ("%g\n", a);
    printf ("%g\n", b);
    printf ("%g\n", c);
    printf ("%g\n", d);
    printf ("%g\n", e);
    printf ("%g\n", f);
}