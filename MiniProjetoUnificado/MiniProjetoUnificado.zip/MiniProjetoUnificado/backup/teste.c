#include <stdio.h>
#include <string.h>

int main (){

    char teste[100];
    scanf ("%[^\':']", teste);

    return 0;
}