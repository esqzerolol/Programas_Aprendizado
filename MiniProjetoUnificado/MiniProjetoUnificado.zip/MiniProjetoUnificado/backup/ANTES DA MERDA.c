#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int main (){

    int num_polinomios;
    int i;
    Poly *pp;  
    Poly *pp;  

    scanf ("%d%*c", &num_polinomios);
    pp = criar_termo(num_polinomios, pp);
    ler_polinomio(num_polinomios, pp);

    return 0;
}


